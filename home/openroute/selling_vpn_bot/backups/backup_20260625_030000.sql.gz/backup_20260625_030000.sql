--
-- PostgreSQL database dump
--

\restrict kX08EEaoiKmVYLFfxDzkwQE5gj68PqhtWsCbwPDqhH8Atcr81yHAyLdLIrtI4jQ

-- Dumped from database version 15.18
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: discount_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_codes (
    id integer NOT NULL,
    code character varying NOT NULL,
    percent_off integer NOT NULL,
    payment_method_scope character varying NOT NULL,
    is_active boolean NOT NULL,
    is_used boolean NOT NULL,
    used_by_user_id bigint,
    used_payment_id integer,
    used_at timestamp with time zone,
    created_by bigint,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.discount_codes OWNER TO postgres;

--
-- Name: discount_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discount_codes_id_seq OWNER TO postgres;

--
-- Name: discount_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_codes_id_seq OWNED BY public.discount_codes.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    server_id integer,
    amount numeric(10,2) NOT NULL,
    currency character varying NOT NULL,
    payment_method character varying NOT NULL,
    card_last_four character varying(4),
    gateway_tx_id character varying,
    status character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    service_type character varying
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: ssh_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ssh_accounts (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    server_id integer NOT NULL,
    payment_id integer,
    ssh_username character varying NOT NULL,
    ssh_password character varying NOT NULL,
    import_link character varying,
    duration_days integer NOT NULL,
    traffic_limit_gb integer,
    traffic_used_gb numeric(12,6) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    status character varying NOT NULL,
    max_connections integer NOT NULL,
    service_type character varying DEFAULT 'ssh'::character varying NOT NULL
);


ALTER TABLE public.ssh_accounts OWNER TO postgres;

--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ssh_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ssh_accounts_id_seq OWNER TO postgres;

--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ssh_accounts_id_seq OWNED BY public.ssh_accounts.id;


--
-- Name: ssh_servers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ssh_servers (
    id integer NOT NULL,
    name character varying NOT NULL,
    ip_address character varying NOT NULL,
    ssh_port integer NOT NULL,
    dropbear_port integer,
    root_password character varying NOT NULL,
    status character varying NOT NULL,
    service_type character varying DEFAULT 'ssh'::character varying NOT NULL
);


ALTER TABLE public.ssh_servers OWNER TO postgres;

--
-- Name: ssh_servers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ssh_servers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ssh_servers_id_seq OWNER TO postgres;

--
-- Name: ssh_servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ssh_servers_id_seq OWNED BY public.ssh_servers.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    subject character varying NOT NULL,
    status character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_messages (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    sender character varying NOT NULL,
    text character varying NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.ticket_messages OWNER TO postgres;

--
-- Name: ticket_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_messages_id_seq OWNER TO postgres;

--
-- Name: ticket_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_messages_id_seq OWNED BY public.ticket_messages.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying,
    language_code character varying NOT NULL,
    balance numeric(10,2) NOT NULL,
    is_admin boolean NOT NULL,
    is_blocked boolean NOT NULL,
    registered_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: discount_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_codes ALTER COLUMN id SET DEFAULT nextval('public.discount_codes_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: ssh_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts ALTER COLUMN id SET DEFAULT nextval('public.ssh_accounts_id_seq'::regclass);


--
-- Name: ssh_servers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_servers ALTER COLUMN id SET DEFAULT nextval('public.ssh_servers_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: ticket_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages ALTER COLUMN id SET DEFAULT nextval('public.ticket_messages_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: discount_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_codes (id, code, percent_off, payment_method_scope, is_active, is_used, used_by_user_id, used_payment_id, used_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, user_id, server_id, amount, currency, payment_method, card_last_four, gateway_tx_id, status, created_at, service_type) FROM stdin;
1	8484717245	2	600000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAICfmo1FHBzzU_42pnx40DgdtRTd6vwAAJlDGsbNImwRcLgwV_7fmMbAQADAgADeQADPAQ	completed	2026-06-19 10:05:36.285435+00	v2ray
2	8484717245	2	800000.00	USD	crypto	\N	nowpayments_invoice:5228710645|payable_toman=800000|payable_usd=7.00	pending	2026-06-19 10:06:03.221634+00	v2ray
5	8484717245	2	268000.00	USD	crypto	\N	nowpayments_invoice:4500590289|payable_toman=268000|payable_usd=3.00	pending	2026-06-24 21:55:05.666032+00	v2ray
6	8484717245	2	358000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAIClGo8Ul40VHDx1VkXDlA8n8VoTxffAAJyDGsbvefgRVJd3-3afiwHAQADAgADeQADPAQ	completed	2026-06-24 21:55:43.087312+00	v2ray
4	8484717245	2	600000.00	USD	crypto	\N	nowpayments_invoice:5540401315|payable_toman=600000|payable_usd=6.00	pending	2026-06-24 21:54:41.45135+00	v2ray
7	8484717245	2	358000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAIClGo8Ul40VHDx1VkXDlA8n8VoTxffAAJyDGsbvefgRVJd3-3afiwHAQADAgADeQADPAQ	completed	2026-06-24 22:08:20.508085+00	\N
8	8484717245	1	600000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAIClGo8Ul40VHDx1VkXDlA8n8VoTxffAAJyDGsbvefgRVJd3-3afiwHAQADAgADeQADPAQ	completed	2026-06-24 22:09:04.081106+00	\N
\.


--
-- Data for Name: ssh_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ssh_accounts (id, user_id, server_id, payment_id, ssh_username, ssh_password, import_link, duration_days, traffic_limit_gb, traffic_used_gb, expires_at, status, max_connections, service_type) FROM stdin;
3	8484717245	1	\N	AmirTEH	15e2cd97-ea04-40b1-b07c-f2c1ba80884a	https://miniapp.ipping.ir:8080/sub/djMsMSwxNzgyMjI5ODkxebfdc048ac	30	\N	0.000000	2026-07-23 15:51:30.947967+00	active	1	v2ray
4	999999	1	\N	pg3_1001	eabf7430-78f5-4693-a235-28a900d56261	https://pi.ipping.ir/sub/djMsMSwxNzgyMDM5NDkw30a2468eee	10	\N	0.000000	2026-07-06 10:58:08+00	active	2	v2ray
5	999999	1	\N	pg3_1002	12ae2b8a-15b0-4c24-97ce-d86ec174d1fa	https://miniapp.ipping.ir/sub/djMsMiwxNzgyMDM5NTcw986cdd9a35	10	\N	0.000000	2026-07-06 10:59:29+00	active	2	v2ray
1	8484717245	1	\N	test	12345	\N	30	\N	0.000000	2026-07-19 09:57:40.326944+00	active	1	ssh
2	8484717245	1	1	openroute_1001	nZESfyHNtW	ssh://openroute_1001:nZESfyHNtW@openroute.ir:2223#VPN_openroute_1001	30	\N	0.000000	2026-07-19 10:05:42.178889+00	active	1	ssh
6	8484717245	1	\N	admintest	12345678	\N	30	\N	0.000000	2026-07-23 13:32:40.272503+00	active	1	ssh
15	8484717245	2	6	openroute_1002	fdcea7fc-6ad1-4f49-b1f9-b9de397c0292	https://p.ipping.ir:8080/sub/djMsMTgsMTc4MjMzODE1Nwb8f13db813	30	\N	0.000000	2026-07-24 21:55:55+00	active	2	v2ray
17	8484717245	1	8	ssh_1001	B2iJP8MHRN	ssh://ssh_1001:B2iJP8MHRN@openroute.ir:2223#SSH_ssh_1001	30	\N	0.000000	2026-07-24 22:09:10.973452+00	active	1	ssh
7	8484717245	1	\N	Amirt2	0c3465c5-e9b9-473c-bc69-63ae3bcff21c	https://p.ipping.ir:8080/sub/djMsMiwxNzgyMjMxNDYy776db67633	30	\N	0.000000	2026-07-23 16:17:40+00	active	1	v2ray
8	8484717245	1	\N	ttttt	1b8971fd-69fe-4ae1-aeb9-8c293533b40b	https://p.ipping.ir:8080/sub/djMsMywxNzgyMjU0MDgzdfc95dd3ac	1	\N	0.000000	2026-06-24 22:34:42+00	active	1	v2ray
9	8484717245	1	\N	test2	2e65c138-3baa-4505-b5c3-92e6f1d3d729	https://p.ipping.ir:8080/sub/djMsNSwxNzgyMjU3MjQz67d29e7e79	1	\N	0.000000	2026-06-24 23:27:22+00	active	1	v2ray
10	8484717245	1	\N	Test3	6fc477c4-d619-4f23-9b5c-b5d19b303a42	https://p.ipping.ir:8080/sub/djMsMTUsMTc4MjI4OTUxNQ73ff61673f	30	\N	0.000000	2026-07-24 08:25:13+00	active	1	v2ray
11	8484717245	1	\N	Test4	942e2de5-1f27-467b-ac14-977e56097400	https://p.ipping.ir:8080/sub/djMsMTYsMTc4MjI5MDAxNgda44d69004	30	\N	0.000000	2026-07-24 08:33:34+00	active	1	v2ray
12	8484717245	1	\N	amirasadmin	a786019b-4c19-4b4b-8d94-48d70738b103	https://p.ipping.ir:8080/sub/djMsMTIsMTc4MjI1OTkwMQ88945c65c4	1	\N	0.000000	2026-06-25 00:11:40+00	active	1	v2ray
13	8484717245	1	\N	amir1	16507540-1fa0-4942-8773-9138120d8cbe	https://p.ipping.ir:8080/sub/djMsMTMsMTc4MjI2MTQ3OQbccce84612	30	\N	0.000000	2026-07-24 00:37:58+00	active	1	v2ray
14	8484717245	1	\N	RezaTest	aae15ae0-7045-41a5-912e-036090ac56d6	https://p.ipping.ir:8080/sub/djMsMTcsMTc4MjI5MDkyMwa234e72e70	30	\N	0.000000	2026-07-24 08:48:41+00	active	1	v2ray
16	8484717245	2	7	openroute_1003	82d449e8-fcd2-46be-bbc3-b84c1d92f243	https://p.ipping.ir:8080/sub/djMsMTksMTc4MjMzODkxMA9c78d20df3	30	30	0.000000	2026-07-24 22:08:28+00	active	2	v2ray
\.


--
-- Data for Name: ssh_servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ssh_servers (id, name, ip_address, ssh_port, dropbear_port, root_password, status, service_type) FROM stdin;
1	OpenRoute Server	openroute_ssh	22	\N	openroute_secure_root_password_123	active	ssh
2	PasarGuard V2Ray	p.ipping.ir	20443	\N	managed-by-pasarguard	active	v2ray
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, user_id, subject, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket_messages (id, ticket_id, sender, text, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, language_code, balance, is_admin, is_blocked, registered_at) FROM stdin;
100554898	rafeiecom	en	0.00	f	f	2026-06-19 09:02:36.265101+00
8484717245	DevTeam2026	en	-600000.00	f	f	2026-06-19 08:59:30.065588+00
402642681	Soul_of_success1	en	0.00	f	f	2026-06-21 18:33:30.927728+00
999999	test_dummy_user	en	100.00	f	f	2026-06-21 10:56:30.046217+00
\.


--
-- Name: discount_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_codes_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 8, true);


--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ssh_accounts_id_seq', 17, true);


--
-- Name: ssh_servers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ssh_servers_id_seq', 2, true);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 1, false);


--
-- Name: ticket_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_messages_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: discount_codes discount_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: ssh_accounts ssh_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_pkey PRIMARY KEY (id);


--
-- Name: ssh_accounts ssh_accounts_ssh_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_ssh_username_key UNIQUE (ssh_username);


--
-- Name: ssh_servers ssh_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_servers
    ADD CONSTRAINT ssh_servers_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_discount_codes_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_discount_codes_code ON public.discount_codes USING btree (code);


--
-- Name: ix_ssh_accounts_payment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ssh_accounts_payment_id ON public.ssh_accounts USING btree (payment_id);


--
-- Name: payments payments_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.ssh_servers(id);


--
-- Name: payments payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ssh_accounts ssh_accounts_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: ssh_accounts ssh_accounts_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.ssh_servers(id);


--
-- Name: ssh_accounts ssh_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- PostgreSQL database dump complete
--

\unrestrict kX08EEaoiKmVYLFfxDzkwQE5gj68PqhtWsCbwPDqhH8Atcr81yHAyLdLIrtI4jQ

