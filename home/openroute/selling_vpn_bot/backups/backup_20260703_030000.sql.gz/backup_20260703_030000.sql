--
-- PostgreSQL database dump
--

\restrict 8riyguubfjgTJtr6PUeOl4EpljeDwwhA4PVr17Ft9JkVmWMRyd9Zy4Uz0Sqcx8y

-- Dumped from database version 15.18
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: discount_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_codes (
    id integer NOT NULL,
    code character varying NOT NULL,
    percent_off integer NOT NULL,
    payment_method_scope character varying NOT NULL,
    is_active boolean NOT NULL,
    is_used boolean NOT NULL,
    used_by_user_id bigint,
    used_payment_id integer,
    used_at timestamp with time zone,
    created_by bigint,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.discount_codes OWNER TO postgres;

--
-- Name: discount_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discount_codes_id_seq OWNER TO postgres;

--
-- Name: discount_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_codes_id_seq OWNED BY public.discount_codes.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    server_id integer,
    amount numeric(10,2) NOT NULL,
    currency character varying NOT NULL,
    payment_method character varying NOT NULL,
    card_last_four character varying(4),
    gateway_tx_id character varying,
    status character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    service_type character varying
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: ssh_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ssh_accounts (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    server_id integer NOT NULL,
    payment_id integer,
    ssh_username character varying NOT NULL,
    ssh_password character varying NOT NULL,
    import_link character varying,
    duration_days integer NOT NULL,
    traffic_limit_gb integer,
    traffic_used_gb numeric(12,6) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    status character varying NOT NULL,
    max_connections integer NOT NULL,
    service_type character varying DEFAULT 'ssh'::character varying NOT NULL
);


ALTER TABLE public.ssh_accounts OWNER TO postgres;

--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ssh_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ssh_accounts_id_seq OWNER TO postgres;

--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ssh_accounts_id_seq OWNED BY public.ssh_accounts.id;


--
-- Name: ssh_servers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ssh_servers (
    id integer NOT NULL,
    name character varying NOT NULL,
    ip_address character varying NOT NULL,
    ssh_port integer NOT NULL,
    dropbear_port integer,
    root_password character varying NOT NULL,
    status character varying NOT NULL,
    service_type character varying DEFAULT 'ssh'::character varying NOT NULL
);


ALTER TABLE public.ssh_servers OWNER TO postgres;

--
-- Name: ssh_servers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ssh_servers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ssh_servers_id_seq OWNER TO postgres;

--
-- Name: ssh_servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ssh_servers_id_seq OWNED BY public.ssh_servers.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    subject character varying NOT NULL,
    status character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_messages (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    sender character varying NOT NULL,
    text character varying NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.ticket_messages OWNER TO postgres;

--
-- Name: ticket_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_messages_id_seq OWNER TO postgres;

--
-- Name: ticket_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_messages_id_seq OWNED BY public.ticket_messages.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying,
    language_code character varying NOT NULL,
    balance numeric(10,2) NOT NULL,
    is_admin boolean NOT NULL,
    is_blocked boolean NOT NULL,
    registered_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: discount_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_codes ALTER COLUMN id SET DEFAULT nextval('public.discount_codes_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: ssh_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts ALTER COLUMN id SET DEFAULT nextval('public.ssh_accounts_id_seq'::regclass);


--
-- Name: ssh_servers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_servers ALTER COLUMN id SET DEFAULT nextval('public.ssh_servers_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: ticket_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages ALTER COLUMN id SET DEFAULT nextval('public.ticket_messages_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: discount_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_codes (id, code, percent_off, payment_method_scope, is_active, is_used, used_by_user_id, used_payment_id, used_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, user_id, server_id, amount, currency, payment_method, card_last_four, gateway_tx_id, status, created_at, service_type) FROM stdin;
1	8484717245	2	600000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAICfmo1FHBzzU_42pnx40DgdtRTd6vwAAJlDGsbNImwRcLgwV_7fmMbAQADAgADeQADPAQ	completed	2026-06-19 10:05:36.285435+00	v2ray
2	8484717245	2	800000.00	USD	crypto	\N	nowpayments_invoice:5228710645|payable_toman=800000|payable_usd=7.00	pending	2026-06-19 10:06:03.221634+00	v2ray
5	8484717245	2	268000.00	USD	crypto	\N	nowpayments_invoice:4500590289|payable_toman=268000|payable_usd=3.00	pending	2026-06-24 21:55:05.666032+00	v2ray
6	8484717245	2	358000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAIClGo8Ul40VHDx1VkXDlA8n8VoTxffAAJyDGsbvefgRVJd3-3afiwHAQADAgADeQADPAQ	completed	2026-06-24 21:55:43.087312+00	v2ray
4	8484717245	2	600000.00	USD	crypto	\N	nowpayments_invoice:5540401315|payable_toman=600000|payable_usd=6.00	pending	2026-06-24 21:54:41.45135+00	v2ray
7	8484717245	2	358000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAIClGo8Ul40VHDx1VkXDlA8n8VoTxffAAJyDGsbvefgRVJd3-3afiwHAQADAgADeQADPAQ	completed	2026-06-24 22:08:20.508085+00	v2ray
8	8484717245	2	600000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAIClGo8Ul40VHDx1VkXDlA8n8VoTxffAAJyDGsbvefgRVJd3-3afiwHAQADAgADeQADPAQ	completed	2026-06-24 22:09:04.081106+00	v2ray
9	8484717245	2	268000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAICpmo9UVCE7MVDdE78h7CGjxTgKqoyAAJvDGsbvefoReyXBSMeIJcHAQADAgADeQADPAQ	completed	2026-06-25 16:03:28.469447+00	v2ray
10	5482209904	2	600000.00	USD	card_to_card	\N	photo:AgACAgQAAxkBAAIDGmo9glQkf-1NaPGOCaqfLDm8a8v7AAJgDmsbHbnxUSLvEmIEWYNfAQADAgADeQADPAQ	completed	2026-06-25 19:32:36.794231+00	v2ray
11	8484717245	2	268000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAMEaj70s61izHwhkFuOxPlE2QLx9iAAAoIMaxvFdvlFQuCc_nXNmzwBAAMCAAN5AAM8BA	pending	2026-06-26 21:53:23.783172+00	v2ray
19	5482209904	2	98000.00	USD	card_to_card	\N	photo:AgACAgEAAyEGAAMBCNH9tgADMGo_jYN-wvxvH7itbSaqde4J6zETAALXC2sbjzH5RRxRPorguRblAQADAgADdwADPAQ	completed	2026-06-27 08:44:49.539316+00	v2ray
13	8484717245	2	98000.00	USD	card_to_card	\N	photo:AgACAgEAAyEGAAMBCNH9tgADHGo--w7LGrhqsPUWjCV32gEAAd1_JwACogtrG48x-UVFDUqUBblXyQEAAwIAA3cAAzwE	pending	2026-06-26 22:19:57.236048+00	v2ray
20	8484717245	1	600000.00	USD	crypto	\N	nowpayments_invoice:5763786230|payable_toman=600000|payable_usd=6.00	pending	2026-07-02 20:38:57.880825+00	ssh
14	8484717245	2	188000.00	USD	card_to_card	\N	photo:AgACAgEAAyEGAAMBCNH9tgADHGo--w7LGrhqsPUWjCV32gEAAd1_JwACogtrG48x-UVFDUqUBblXyQEAAwIAA3cAAzwE	provisioning_failed	2026-06-26 22:20:25.708061+00	v2ray
21	5482209904	\N	6000000.00	USD	crypto	\N	nowpayments_invoice:5002253655|payable_toman=6000000|payable_usd=100.00	pending	2026-07-02 23:58:16.320122+00	wallet
12	8484717245	2	600000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAMMaj76HqcVg73th1tEA29lgGIV9GEAAoQMaxvFdvlFrKY2isVDOuQBAAMCAAN5AAM8BA	completed	2026-06-26 22:15:58.963695+00	v2ray
22	5482209904	\N	6000000.00	USD	crypto	\N	nowpayments_invoice:6172773382|payable_toman=6000000|payable_usd=100.00	pending	2026-07-02 23:58:21.412628+00	wallet
15	8484717245	2	188000.00	USD	card_to_card	\N	photo:AgACAgEAAyEGAAMBCNH9tgADH2o-_7FRE58zdu3hj3-LqtV3ihysAAKkC2sbjzH5RYHAbO9rGO0rAQADAgADdwADPAQ	completed	2026-06-26 22:39:43.899606+00	v2ray
23	5482209904	\N	6000000.00	USD	crypto	\N	nowpayments_invoice:5496309974|payable_toman=6000000|payable_usd=100.00	pending	2026-07-03 00:02:38.585828+00	wallet
16	8484717245	1	800000.00	USD	card_to_card	\N	photo:AgACAgEAAyEGAAMBCNH9tgADIGo_BX5g3m6KkZhlyD5YIHPtKfbUAAKnC2sbjzH5RaQUXIe9enkyAQADAgADdwADPAQ	completed	2026-06-26 23:04:28.68831+00	ssh
24	5482209904	\N	60000000.00	USD	crypto	\N	nowpayments_invoice:4295625162|payable_toman=60000000|payable_usd=1000.00	pending	2026-07-03 00:03:17.928298+00	wallet
17	8484717245	2	268000.00	USD	card_to_card	\N	photo:AgACAgEAAyEGAAMBCNH9tgADIGo_BX5g3m6KkZhlyD5YIHPtKfbUAAKnC2sbjzH5RaQUXIe9enkyAQADAgADdwADPAQ	completed	2026-06-26 23:05:17.034476+00	v2ray
25	5482209904	\N	60000000.00	USD	crypto	\N	nowpayments_invoice:6113855016|payable_toman=60000000|payable_usd=1000.00	pending	2026-07-03 00:03:37.232116+00	wallet
18	8484717245	1	600000.00	USD	card_to_card	\N	photo:AgACAgEAAyEGAAMBCNH9tgADL2o_jQM73_NztjLR9Lxb5uOjNX9EAALVC2sbjzH5RfoSsHF10A_dAQADAgADeQADPAQ	completed	2026-06-27 08:42:42.630322+00	ssh
26	5482209904	2	698000.00	USD	crypto	\N	nowpayments_invoice:4928455879|payable_toman=698000|payable_usd=7.00	pending	2026-07-03 01:13:11.082771+00	v2ray
\.


--
-- Data for Name: ssh_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ssh_accounts (id, user_id, server_id, payment_id, ssh_username, ssh_password, import_link, duration_days, traffic_limit_gb, traffic_used_gb, expires_at, status, max_connections, service_type) FROM stdin;
36	8484717245	1	\N	Jamal	KvgTnWytkk	ssh://Jamal:KvgTnWytkk@openroute.ir:2223#SSH_Jamal	30	\N	0.000000	2026-07-28 09:57:46.24949+00	active	1	ssh
41	8484717245	1	\N	Behnam	vfSvDdJ0UJ	ssh://Behnam:vfSvDdJ0UJ@openroute.ir:2223#SSH_Behnam	30	\N	0.000000	2026-07-28 10:08:27.994328+00	active	1	ssh
21	8484717245	1	12	ssh_1003	MK23JFF1A3	ssh://ssh_1003:MK23JFF1A3@openroute.ir:2223#SSH_ssh_1003	30	\N	0.000000	2026-07-26 22:16:09.967513+00	active	1	ssh
15	8484717245	2	6	openroute_1002	fdcea7fc-6ad1-4f49-b1f9-b9de397c0292	https://p.ipping.ir:8080/sub/djMsMTgsMTc4MjMzODE1Nwb8f13db813	30	\N	0.000021	2026-07-24 21:55:55+00	active	2	v2ray
19	8484717245	2	\N	me123	cbbd30ee-776a-4599-aa5e-c88acaaff20d	https://p.ipping.ir:8080/sub/djMsMjEsMTc4MjQxNDYzMw42d0b6e868	30	\N	0.000014	2026-07-25 19:10:32+00	active	1	v2ray
38	8484717245	1	\N	This_is_for_Milad	oojpSEt6s7	ssh://This_is_for_Milad:oojpSEt6s7@openroute.ir:2223#SSH_This_is_for_Milad	30	\N	0.000000	2026-07-28 10:03:23.636215+00	active	1	ssh
40	8484717245	2	\N	THIS_IS_FOR_BEHNAM	fce8d40e-d5ad-48b7-8901-89c27fabc060	https://p.ipping.ir:8080/sub/djMsMzAsMTc4MjY0MTI1Mw337b319eff	30	\N	10.335443	2026-07-28 10:07:32+00	active	1	v2ray
35	7218240662	2	\N	openroute_1015	22c65f72-4aba-438a-9369-08adfcf7a695	https://p.ipping.ir:8080/sub/djMsMjYsMTc4MjYwNjg2NQ5141e9065b	1	\N	0.000000	2026-06-29 00:34:24+00	locked	1	v2ray
39	8484717245	1	\N	This_is_for_Family	FqryvOTBAY	ssh://This_is_for_Family:FqryvOTBAY@openroute.ir:2223#SSH_This_is_for_Family	30	\N	0.000000	2026-07-28 10:05:29.351067+00	active	1	ssh
43	8484717245	1	\N	PARNIA	Ow9VyOduaN	ssh://PARNIA:Ow9VyOduaN@openroute.ir:2223#SSH_PARNIA	30	\N	0.000000	2026-07-28 10:09:34.651226+00	active	1	ssh
53	8484717245	1	\N	m7	f361WfCo04	ssh://m7:f361WfCo04@openroute.ir:2223#SSH_m7	30	\N	0.000000	2026-07-31 15:23:11.205645+00	active	1	ssh
14	8484717245	1	\N	RezaTest	aae15ae0-7045-41a5-912e-036090ac56d6	https://p.ipping.ir:8080/sub/djMsMTcsMTc4MjI5MDkyMwa234e72e70	30	\N	0.000100	2026-07-24 08:48:41+00	active	1	v2ray
23	8484717245	1	16	ssh_1004	5xVX1PBCvv	ssh://ssh_1004:5xVX1PBCvv@openroute.ir:2223#SSH_ssh_1004	30	\N	0.000000	2026-07-26 23:04:37.233384+00	active	2	ssh
51	8484717245	1	\N	m5	W7eBn9WpAt	ssh://m5:W7eBn9WpAt@openroute.ir:2223#SSH_m5	30	\N	0.000000	2026-07-31 15:22:04.190658+00	active	1	ssh
52	8484717245	1	\N	m6	6GMrL4Pr70	ssh://m6:6GMrL4Pr70@openroute.ir:2223#SSH_m6	30	\N	0.000000	2026-07-31 15:22:35.515448+00	active	1	ssh
47	8484717245	1	\N	m1	JGy3rl3n83	ssh://m1:JGy3rl3n83@openroute.ir:2223#SSH_m1	30	\N	0.000000	2026-07-31 15:19:41.761813+00	active	1	ssh
48	8484717245	1	\N	m2	zzGQwyLjTf	ssh://m2:zzGQwyLjTf@openroute.ir:2223#SSH_m2	30	\N	0.000000	2026-07-31 15:20:14.44924+00	active	1	ssh
49	8484717245	1	\N	m3	sKIBkp3qxn	ssh://m3:sKIBkp3qxn@openroute.ir:2223#SSH_m3	30	\N	0.000000	2026-07-31 15:20:52.409272+00	active	1	ssh
50	8484717245	1	\N	m4	cNxY8Aq6U4	ssh://m4:cNxY8Aq6U4@openroute.ir:2223#SSH_m4	30	\N	0.000000	2026-07-31 15:21:28.620594+00	active	1	ssh
3	8484717245	1	\N	AmirTEH	15e2cd97-ea04-40b1-b07c-f2c1ba80884a	https://miniapp.ipping.ir:8080/sub/djMsMSwxNzgyMjI5ODkxebfdc048ac	30	\N	0.000000	2026-07-23 15:51:30.947967+00	active	1	v2ray
4	999999	1	\N	pg3_1001	eabf7430-78f5-4693-a235-28a900d56261	https://pi.ipping.ir/sub/djMsMSwxNzgyMDM5NDkw30a2468eee	10	\N	0.000000	2026-07-06 10:58:08+00	active	2	v2ray
5	999999	1	\N	pg3_1002	12ae2b8a-15b0-4c24-97ce-d86ec174d1fa	https://miniapp.ipping.ir/sub/djMsMiwxNzgyMDM5NTcw986cdd9a35	10	\N	0.000000	2026-07-06 10:59:29+00	active	2	v2ray
1	8484717245	1	\N	test	12345	\N	30	\N	0.000000	2026-07-19 09:57:40.326944+00	active	1	ssh
2	8484717245	1	1	openroute_1001	nZESfyHNtW	ssh://openroute_1001:nZESfyHNtW@openroute.ir:2223#VPN_openroute_1001	30	\N	0.000000	2026-07-19 10:05:42.178889+00	active	1	ssh
6	8484717245	1	\N	admintest	12345678	\N	30	\N	0.000000	2026-07-23 13:32:40.272503+00	active	1	ssh
17	8484717245	1	8	ssh_1001	B2iJP8MHRN	ssh://ssh_1001:B2iJP8MHRN@openroute.ir:2223#SSH_ssh_1001	30	\N	0.000000	2026-07-24 22:09:10.973452+00	active	1	ssh
20	5482209904	1	10	ssh_1002	BM9aKjr2A9	ssh://ssh_1002:BM9aKjr2A9@openroute.ir:2223#SSH_ssh_1002	30	\N	0.000000	2026-07-25 19:32:49.0685+00	active	1	ssh
7	8484717245	1	\N	Amirt2	0c3465c5-e9b9-473c-bc69-63ae3bcff21c	https://p.ipping.ir:8080/sub/djMsMiwxNzgyMjMxNDYy776db67633	30	\N	0.000000	2026-07-23 16:17:40+00	active	1	v2ray
8	8484717245	1	\N	ttttt	1b8971fd-69fe-4ae1-aeb9-8c293533b40b	https://p.ipping.ir:8080/sub/djMsMywxNzgyMjU0MDgzdfc95dd3ac	1	\N	0.000000	2026-06-24 22:34:42+00	active	1	v2ray
42	8484717245	2	\N	Mehrdad	d34e8475-cf68-4fef-ac13-2333d0cdc2b6	https://p.ipping.ir:8080/sub/djMsMzEsMTc4MjY0MTMzMA5ac44464be	30	\N	4.200233	2026-07-28 10:08:49+00	active	1	v2ray
13	8484717245	1	\N	amir1	16507540-1fa0-4942-8773-9138120d8cbe	https://p.ipping.ir:8080/sub/djMsMTMsMTc4MjI2MTQ3OQbccce84612	30	\N	0.000114	2026-07-24 00:37:58+00	active	1	v2ray
44	754767232	2	\N	openroute_1016	3c30b9e9-3c2f-4a26-9ba9-757d069ab5fc	https://p.ipping.ir:8080/sub/djMsMzIsMTc4MjY2ODc5Nw72387fb4c7	1	\N	0.000000	2026-06-29 17:46:36+00	active	1	v2ray
45	861545307	2	\N	openroute_1017	817be11e-0bd3-481d-9008-2c0bf069263a	https://p.ipping.ir:8080/sub/djMsMzMsMTc4Mjc0MzY4MQ3a7e60d664	1	\N	0.000000	2026-06-30 14:34:39+00	active	1	v2ray
37	8484717245	1	\N	This_is_for_CAT	mX64WTAHsp	ssh://This_is_for_CAT:mX64WTAHsp@openroute.ir:2223#SSH_This_is_for_CAT	30	\N	0.000000	2026-07-28 10:00:57.578004+00	active	1	ssh
30	64999057	2	\N	openroute_1010	abc26d99-c11f-4eef-85d9-a33ebf67ccee	https://p.ipping.ir:8080/sub/djMsMjEsMTc4MjU1ODEzMQ555d8dcb2a	1	\N	0.000078	2026-06-28 11:02:10+00	locked	1	v2ray
33	8707564258	2	\N	openroute_1013	c4fb953a-3ff9-49cb-949d-c4183a3f511b	https://p.ipping.ir:8080/sub/djMsMjQsMTc4MjU2MTIwNw768ed0acd1	1	\N	0.000425	2026-06-28 11:53:26+00	locked	1	v2ray
34	8150441612	2	\N	openroute_1014	22140462-bf8a-4cbf-9e28-4215c1c58e3d	https://p.ipping.ir:8080/sub/djMsMjUsMTc4MjU2NzQzMQe780696131	1	\N	0.000077	2026-06-28 13:37:10+00	locked	1	v2ray
32	6337234704	2	\N	openroute_1012	1300f65e-1479-4cc3-8334-5c4f5d6fe8aa	https://p.ipping.ir:8080/sub/djMsMjMsMTc4MjU2MDExMQc28c600e47	1	\N	0.000065	2026-06-28 11:35:10+00	locked	1	v2ray
31	1711243565	2	\N	openroute_1011	3b308890-6ef2-4625-acc2-9ac88d9fcadf	https://p.ipping.ir:8080/sub/djMsMjIsMTc4MjU1ODg5NQ92f425ccf6	1	\N	0.000154	2026-06-28 11:14:53+00	locked	1	v2ray
29	109761354	2	\N	openroute_1009	7e4b31ed-3ce2-40a9-be0a-84d8fdc70df7	https://p.ipping.ir:8080/sub/djMsMTgsMTc4MjU1NTQ2NA4760a08fe9	1	\N	0.000000	2026-06-28 10:17:43+00	locked	1	v2ray
28	1036156274	2	\N	openroute_1008	e22db5ab-b41e-4e67-8d07-9cee1c1ffd84	https://p.ipping.ir:8080/sub/djMsMTcsMTc4MjU1NTEzNg09b32b96c6	1	\N	0.000000	2026-06-28 10:12:15+00	locked	1	v2ray
24	8484717245	2	17	openroute_1006	41da426d-f6ef-4492-87ff-2b3f9326420d	https://p.ipping.ir:8080/sub/djMsMywxNzgyNTE1MTI1d39b4db3fb	30	\N	0.000000	2026-07-26 23:05:23+00	active	2	v2ray
46	581332177	2	\N	openroute_1018	4caa9f8a-8269-45d5-a0df-5a6b60bd7d18	https://p.ipping.ir:8080/sub/djMsMzQsMTc4Mjg1NDI1MAc96abab246	1	\N	0.000000	2026-07-01 21:17:29+00	active	1	v2ray
26	8484717245	1	18	ssh_1005	jIanFVsBcS	ssh://ssh_1005:jIanFVsBcS@openroute.ir:2223#SSH_ssh_1005	30	\N	0.000000	2026-07-27 08:42:56.552+00	active	1	ssh
9	8484717245	1	\N	test2	2e65c138-3baa-4505-b5c3-92e6f1d3d729	https://p.ipping.ir:8080/sub/djMsNSwxNzgyMjU3MjQz67d29e7e79	1	\N	0.000000	2026-06-24 23:27:22+00	active	1	v2ray
10	8484717245	1	\N	Test3	6fc477c4-d619-4f23-9b5c-b5d19b303a42	https://p.ipping.ir:8080/sub/djMsMTUsMTc4MjI4OTUxNQ73ff61673f	30	\N	0.000000	2026-07-24 08:25:13+00	active	1	v2ray
11	8484717245	1	\N	Test4	942e2de5-1f27-467b-ac14-977e56097400	https://p.ipping.ir:8080/sub/djMsMTYsMTc4MjI5MDAxNgda44d69004	30	\N	0.000000	2026-07-24 08:33:34+00	active	1	v2ray
16	8484717245	2	7	openroute_1003	82d449e8-fcd2-46be-bbc3-b84c1d92f243	https://p.ipping.ir:8080/sub/djMsMTksMTc4MjMzODkxMA9c78d20df3	30	\N	0.000000	2026-07-24 22:08:28+00	active	2	v2ray
12	8484717245	1	\N	amirasadmin	a786019b-4c19-4b4b-8d94-48d70738b103	https://p.ipping.ir:8080/sub/djMsMTIsMTc4MjI1OTkwMQ88945c65c4	1	\N	1.027657	2026-06-25 00:11:40+00	active	1	v2ray
22	8484717245	2	15	openroute_1005	b97a5d9d-b703-4f76-84e9-e7f426f45378	https://p.ipping.ir:8080/sub/djMsMiwxNzgyNTEzNTky4e22f1a1a9	30	\N	0.008770	2026-07-26 22:39:51+00	active	1	v2ray
25	8484717245	2	\N	metest	1029b966-0602-4edc-8028-43377e8b3c8f	https://p.ipping.ir:8080/sub/djMsNCwxNzgyNTE1Mjgxe282534735	30	\N	0.644722	2026-07-26 23:08:00+00	active	1	v2ray
27	5482209904	2	19	openroute_1007	186d97c7-d0ef-45d9-87d2-e4ee70fe1a14	https://p.ipping.ir:8080/sub/djMsMTYsMTc4MjU0OTkwNw836ba3847a	30	\N	0.208176	2026-07-27 08:45:06+00	active	1	v2ray
18	8484717245	2	9	openroute_1004	563e88d9-2919-4a69-80af-f17a555dc255	https://p.ipping.ir:8080/sub/djMsMjAsMTc4MjQwMzQxNg6d2995a8a7	30	\N	0.000007	2026-07-25 16:03:35+00	active	2	v2ray
54	8484717245	1	\N	m8	tjxLU9QESB	ssh://m8:tjxLU9QESB@openroute.ir:2223#SSH_m8	30	\N	0.000000	2026-07-31 15:23:41.742157+00	active	1	ssh
55	8484717245	1	\N	m9	3lloJiNgch	ssh://m9:3lloJiNgch@openroute.ir:2223#SSH_m9	30	\N	0.000000	2026-07-31 15:24:12.062373+00	active	1	ssh
56	8484717245	1	\N	m10	prW9ZPUyhc	ssh://m10:prW9ZPUyhc@openroute.ir:2223#SSH_m10	30	\N	0.000000	2026-07-31 15:24:54.468128+00	active	1	ssh
\.


--
-- Data for Name: ssh_servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ssh_servers (id, name, ip_address, ssh_port, dropbear_port, root_password, status, service_type) FROM stdin;
1	OpenRoute Server	openroute_ssh	22	\N	openroute_secure_root_password_123	active	ssh
2	PasarGuard V2Ray	p.ipping.ir	20443	\N	managed-by-pasarguard	active	v2ray
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, user_id, subject, status, created_at, updated_at) FROM stdin;
2	8484717245	salam	open	2026-06-25 18:05:22.69358+00	2026-06-25 18:05:22.693588+00
1	8484717245	Ssh	resolved	2026-06-25 16:04:37.116664+00	2026-06-25 18:11:35.711984+00
3	861545307	امیر جان پیام بده	resolved	2026-06-29 14:35:29.824665+00	2026-06-29 15:26:11.210534+00
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket_messages (id, ticket_id, sender, text, created_at) FROM stdin;
1	1	user	1	2026-06-25 16:04:37.129139+00
2	2	user	salam	2026-06-25 18:05:22.703131+00
3	1	user	1	2026-06-25 18:08:21.223336+00
4	1	admin	salam	2026-06-25 18:11:35.71479+00
5	3	user	امیر جان @Radikal1_2006 یه پیام بده	2026-06-29 14:35:29.850413+00
6	3	admin	shoma	2026-06-29 15:26:11.217131+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, language_code, balance, is_admin, is_blocked, registered_at) FROM stdin;
999999	test_dummy_user	en	100.00	f	t	2026-06-21 10:56:30.046217+00
402642681	Soul_of_success1	en	0.00	f	t	2026-06-21 18:33:30.927728+00
1036156274	\N	en	0.00	f	f	2026-06-27 10:12:08.673404+00
8588782169	chillychickenn	en	0.00	f	f	2026-06-27 10:16:32.462041+00
109761354	rezahashemi46	en	0.00	f	f	2026-06-27 10:17:39.549555+00
7900316430	SwissAir1550	fa	0.00	f	f	2026-06-27 10:36:19.353369+00
8705949113	negligible1	en	0.00	f	f	2026-06-27 11:00:28.353983+00
64999057	MRN40	en	0.00	f	f	2026-06-27 11:01:59.400187+00
6898851865	rezamehr785	fa	0.00	f	f	2026-06-27 11:02:57.795054+00
158081428	Mosavi2711369	fa	0.00	f	f	2026-06-27 11:05:56.673902+00
7850108122	Reall_sara	en	0.00	f	f	2026-06-27 11:07:45.404458+00
82669242	Fardin7101	en	0.00	f	f	2026-06-27 11:07:55.191073+00
1711243565	sajedeh_shahmoradi	fa	0.00	f	f	2026-06-27 11:14:23.687977+00
7179585843	sbvsgdee	ar	0.00	f	f	2026-06-27 11:17:06.831024+00
6337234704	ArtinSaeedi1	en	0.00	f	f	2026-06-27 11:34:20.486983+00
7077032049	\N	fa	0.00	f	f	2026-06-27 11:42:24.836928+00
8707564258	Uff_offten	en	0.00	f	f	2026-06-27 11:53:19.87919+00
8210868368	\N	fa	0.00	f	f	2026-06-27 11:57:44.229535+00
8150441612	haamiidaam	fa	0.00	f	f	2026-06-27 13:37:03.492811+00
7218240662	\N	ar	0.00	f	f	2026-06-28 00:34:15.517838+00
754767232	ntkpuzzlepieces	id	0.00	f	f	2026-06-28 17:46:09.71808+00
861545307	Radikal1_2006	en	0.00	f	f	2026-06-29 14:34:33.000041+00
572562437	Zr_so_m	fa	0.00	f	f	2026-06-29 19:31:38.615032+00
5010643278	\N	en	0.00	f	f	2026-06-30 04:03:45.845041+00
581332177	a1b5d1	ar	0.00	f	f	2026-06-30 19:43:11.1957+00
964550145	eng_1amjed	ar	0.00	f	f	2026-07-01 08:42:28.045735+00
8484717245	DevTeam2026	en	0.00	t	f	2026-06-19 08:59:30.065588+00
100554898	rafeiecom	en	0.00	f	f	2026-06-19 09:02:36.265101+00
5482209904	amirhosseinNader_1997	en	0.00	t	f	2026-06-25 19:32:00.318101+00
\.


--
-- Name: discount_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_codes_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 26, true);


--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ssh_accounts_id_seq', 56, true);


--
-- Name: ssh_servers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ssh_servers_id_seq', 2, true);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 3, true);


--
-- Name: ticket_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_messages_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: discount_codes discount_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: ssh_accounts ssh_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_pkey PRIMARY KEY (id);


--
-- Name: ssh_accounts ssh_accounts_ssh_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_ssh_username_key UNIQUE (ssh_username);


--
-- Name: ssh_servers ssh_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_servers
    ADD CONSTRAINT ssh_servers_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_discount_codes_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_discount_codes_code ON public.discount_codes USING btree (code);


--
-- Name: ix_ssh_accounts_payment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ssh_accounts_payment_id ON public.ssh_accounts USING btree (payment_id);


--
-- Name: payments payments_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.ssh_servers(id);


--
-- Name: payments payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ssh_accounts ssh_accounts_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: ssh_accounts ssh_accounts_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.ssh_servers(id);


--
-- Name: ssh_accounts ssh_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 8riyguubfjgTJtr6PUeOl4EpljeDwwhA4PVr17Ft9JkVmWMRyd9Zy4Uz0Sqcx8y

