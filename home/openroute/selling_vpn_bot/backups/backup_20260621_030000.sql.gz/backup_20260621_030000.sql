--
-- PostgreSQL database dump
--

\restrict 6TGsUxwl1T6fQrsjJT3uUGNDRHbKzL8Ug9Ge8DMoipg6KQkcFKkRhT52ZFKjfNl

-- Dumped from database version 15.18
-- Dumped by pg_dump version 17.10 (Debian 17.10-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: discount_codes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.discount_codes (
    id integer NOT NULL,
    code character varying NOT NULL,
    percent_off integer NOT NULL,
    payment_method_scope character varying NOT NULL,
    is_active boolean NOT NULL,
    is_used boolean NOT NULL,
    used_by_user_id bigint,
    used_payment_id integer,
    used_at timestamp with time zone,
    created_by bigint,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.discount_codes OWNER TO postgres;

--
-- Name: discount_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.discount_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.discount_codes_id_seq OWNER TO postgres;

--
-- Name: discount_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.discount_codes_id_seq OWNED BY public.discount_codes.id;


--
-- Name: payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    server_id integer,
    amount numeric(10,2) NOT NULL,
    currency character varying NOT NULL,
    payment_method character varying NOT NULL,
    card_last_four character varying(4),
    gateway_tx_id character varying,
    status character varying NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.payments OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.payments_id_seq OWNER TO postgres;

--
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- Name: ssh_accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ssh_accounts (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    server_id integer NOT NULL,
    payment_id integer,
    ssh_username character varying NOT NULL,
    ssh_password character varying NOT NULL,
    import_link character varying,
    duration_days integer NOT NULL,
    traffic_limit_gb integer,
    traffic_used_gb numeric(12,6) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    status character varying NOT NULL,
    max_connections integer NOT NULL
);


ALTER TABLE public.ssh_accounts OWNER TO postgres;

--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ssh_accounts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ssh_accounts_id_seq OWNER TO postgres;

--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ssh_accounts_id_seq OWNED BY public.ssh_accounts.id;


--
-- Name: ssh_servers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ssh_servers (
    id integer NOT NULL,
    name character varying NOT NULL,
    ip_address character varying NOT NULL,
    ssh_port integer NOT NULL,
    dropbear_port integer,
    root_password character varying NOT NULL,
    status character varying NOT NULL
);


ALTER TABLE public.ssh_servers OWNER TO postgres;

--
-- Name: ssh_servers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ssh_servers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ssh_servers_id_seq OWNER TO postgres;

--
-- Name: ssh_servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ssh_servers_id_seq OWNED BY public.ssh_servers.id;


--
-- Name: support_tickets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.support_tickets (
    id integer NOT NULL,
    user_id bigint NOT NULL,
    subject character varying NOT NULL,
    status character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.support_tickets OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.support_tickets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.support_tickets_id_seq OWNER TO postgres;

--
-- Name: support_tickets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.support_tickets_id_seq OWNED BY public.support_tickets.id;


--
-- Name: ticket_messages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ticket_messages (
    id integer NOT NULL,
    ticket_id integer NOT NULL,
    sender character varying NOT NULL,
    text character varying NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.ticket_messages OWNER TO postgres;

--
-- Name: ticket_messages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ticket_messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ticket_messages_id_seq OWNER TO postgres;

--
-- Name: ticket_messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ticket_messages_id_seq OWNED BY public.ticket_messages.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying,
    language_code character varying NOT NULL,
    balance numeric(10,2) NOT NULL,
    is_admin boolean NOT NULL,
    is_blocked boolean NOT NULL,
    registered_at timestamp with time zone NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: discount_codes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_codes ALTER COLUMN id SET DEFAULT nextval('public.discount_codes_id_seq'::regclass);


--
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- Name: ssh_accounts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts ALTER COLUMN id SET DEFAULT nextval('public.ssh_accounts_id_seq'::regclass);


--
-- Name: ssh_servers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_servers ALTER COLUMN id SET DEFAULT nextval('public.ssh_servers_id_seq'::regclass);


--
-- Name: support_tickets id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets ALTER COLUMN id SET DEFAULT nextval('public.support_tickets_id_seq'::regclass);


--
-- Name: ticket_messages id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages ALTER COLUMN id SET DEFAULT nextval('public.ticket_messages_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: discount_codes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.discount_codes (id, code, percent_off, payment_method_scope, is_active, is_used, used_by_user_id, used_payment_id, used_at, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payments (id, user_id, server_id, amount, currency, payment_method, card_last_four, gateway_tx_id, status, created_at) FROM stdin;
1	8484717245	1	600000.00	USD	card_to_card	\N	photo:AgACAgEAAxkBAAICfmo1FHBzzU_42pnx40DgdtRTd6vwAAJlDGsbNImwRcLgwV_7fmMbAQADAgADeQADPAQ	completed	2026-06-19 10:05:36.285435+00
2	8484717245	1	800000.00	USD	crypto	\N	nowpayments_invoice:5228710645|payable_toman=800000|payable_usd=7.00	pending	2026-06-19 10:06:03.221634+00
\.


--
-- Data for Name: ssh_accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ssh_accounts (id, user_id, server_id, payment_id, ssh_username, ssh_password, import_link, duration_days, traffic_limit_gb, traffic_used_gb, expires_at, status, max_connections) FROM stdin;
1	8484717245	1	\N	test	12345	\N	30	\N	0.000261	2026-07-19 09:57:40.326944+00	active	1
2	8484717245	1	1	openroute_1001	nZESfyHNtW	ssh://openroute_1001:nZESfyHNtW@openroute.ir:2223#VPN_openroute_1001	30	\N	0.000656	2026-07-19 10:05:42.178889+00	active	1
\.


--
-- Data for Name: ssh_servers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ssh_servers (id, name, ip_address, ssh_port, dropbear_port, root_password, status) FROM stdin;
1	OpenRoute Server	openroute_ssh	22	\N	openroute_secure_root_password_123	active
\.


--
-- Data for Name: support_tickets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.support_tickets (id, user_id, subject, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ticket_messages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ticket_messages (id, ticket_id, sender, text, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, language_code, balance, is_admin, is_blocked, registered_at) FROM stdin;
100554898	rafeiecom	en	0.00	f	f	2026-06-19 09:02:36.265101+00
8484717245	DevTeam2026	en	-600000.00	f	f	2026-06-19 08:59:30.065588+00
\.


--
-- Name: discount_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.discount_codes_id_seq', 1, false);


--
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.payments_id_seq', 2, true);


--
-- Name: ssh_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ssh_accounts_id_seq', 2, true);


--
-- Name: ssh_servers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ssh_servers_id_seq', 1, true);


--
-- Name: support_tickets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.support_tickets_id_seq', 1, false);


--
-- Name: ticket_messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ticket_messages_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: discount_codes discount_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.discount_codes
    ADD CONSTRAINT discount_codes_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: ssh_accounts ssh_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_pkey PRIMARY KEY (id);


--
-- Name: ssh_accounts ssh_accounts_ssh_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_ssh_username_key UNIQUE (ssh_username);


--
-- Name: ssh_servers ssh_servers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_servers
    ADD CONSTRAINT ssh_servers_pkey PRIMARY KEY (id);


--
-- Name: support_tickets support_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_pkey PRIMARY KEY (id);


--
-- Name: ticket_messages ticket_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_discount_codes_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_discount_codes_code ON public.discount_codes USING btree (code);


--
-- Name: ix_ssh_accounts_payment_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_ssh_accounts_payment_id ON public.ssh_accounts USING btree (payment_id);


--
-- Name: payments payments_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.ssh_servers(id);


--
-- Name: payments payments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ssh_accounts ssh_accounts_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id);


--
-- Name: ssh_accounts ssh_accounts_server_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_server_id_fkey FOREIGN KEY (server_id) REFERENCES public.ssh_servers(id);


--
-- Name: ssh_accounts ssh_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ssh_accounts
    ADD CONSTRAINT ssh_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: support_tickets support_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.support_tickets
    ADD CONSTRAINT support_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: ticket_messages ticket_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ticket_messages
    ADD CONSTRAINT ticket_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.support_tickets(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 6TGsUxwl1T6fQrsjJT3uUGNDRHbKzL8Ug9Ge8DMoipg6KQkcFKkRhT52ZFKjfNl

